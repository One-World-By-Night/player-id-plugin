<?php
/**
 * Plugin Name: WP OAuth Client - Player ID Integration
 * Description: Captures player_id from WP OAuth SSO server
 * Version: 3.2.0
 */

// Helper function to write to local debug.log
function pid_log($message) {
    $log_file = plugin_dir_path(__FILE__) . 'debug.log';
    $timestamp = date('[Y-m-d H:i:s]');
    file_put_contents($log_file, "$timestamp $message\n", FILE_APPEND);
}

// Hook into WP OAuth Client's user data filter
add_filter('wp_oauth_client_user_data', function($user_data, $provider) {
    pid_log("WP OAuth Client user_data received from provider '$provider'");
    pid_log("Data: " . print_r($user_data, true));
    
    if (isset($user_data['player_id'])) {
        pid_log("Found player_id: " . $user_data['player_id']);
        
        // Store in transient for processing after user is created/logged in
        if (isset($user_data['user_email'])) {
            set_transient('oauth_player_id_' . md5($user_data['user_email']), $user_data['player_id'], 300);
            pid_log("Stored player_id in transient for email: " . $user_data['user_email']);
        }
    }
    
    return $user_data;
}, 10, 2);

// Hook into WP OAuth Client's user info filter (from /me endpoint)
add_filter('wp_oauth_client_user_info', function($user_info) {
    pid_log("WP OAuth Client user_info received");
    pid_log("Info: " . print_r($user_info, true));
    
    if (isset($user_info['player_id'])) {
        pid_log("Found player_id in user_info: " . $user_info['player_id']);
        
        // Try to find and update user
        if (isset($user_info['user_email'])) {
            $user = get_user_by('email', $user_info['user_email']);
            if ($user) {
                update_user_meta($user->ID, 'player_id', $user_info['player_id']);
                pid_log("Updated player_id for user {$user->ID}");
            }
        }
    }
    
    return $user_info;
}, 10, 1);

// Hook when WP OAuth Client logs in a user
add_action('wp_oauth_client_user_logged_in', function($user_id, $user_data, $provider) {
    pid_log("WP OAuth Client logged in user $user_id from provider '$provider'");
    pid_log("User data at login: " . print_r($user_data, true));
    
    if (isset($user_data['player_id'])) {
        update_user_meta($user_id, 'player_id', $user_data['player_id']);
        pid_log("Set player_id for user $user_id: " . $user_data['player_id']);
    }
    
    // Check for transient
    if (isset($user_data['user_email'])) {
        $transient_key = 'oauth_player_id_' . md5($user_data['user_email']);
        $player_id = get_transient($transient_key);
        if ($player_id) {
            update_user_meta($user_id, 'player_id', $player_id);
            delete_transient($transient_key);
            pid_log("Applied transient player_id to user $user_id");
        }
    }
}, 10, 3);

// Hook when user is authenticated via OAuth
add_action('wp_oauth_client_authenticated', function($user, $provider) {
    pid_log("WP OAuth Client authenticated user from provider '$provider'");
    pid_log("User object: " . print_r($user, true));
    
    if (is_object($user) && isset($user->ID)) {
        // Check for email-based transient
        $transient_key = 'oauth_player_id_' . md5($user->user_email);
        $player_id = get_transient($transient_key);
        if ($player_id) {
            update_user_meta($user->ID, 'player_id', $player_id);
            delete_transient($transient_key);
            pid_log("Applied player_id from transient to authenticated user {$user->ID}");
        }
    }
}, 10, 2);

// Also try the generic wp_login hook
add_action('wp_login', function($user_login, $user) {
    pid_log("wp_login triggered for user {$user->ID} ({$user_login})");
    
    // Check for transient based on email
    $transient_key = 'oauth_player_id_' . md5($user->user_email);
    $player_id = get_transient($transient_key);
    if ($player_id) {
        update_user_meta($user->ID, 'player_id', $player_id);
        delete_transient($transient_key);
        pid_log("Applied player_id from transient on wp_login for user {$user->ID}");
    }
}, 10, 2);

// Display in user profile
add_action('show_user_profile', 'show_player_id_field');
add_action('edit_user_profile', 'show_player_id_field');

function show_player_id_field($user) {
    $player_id = get_user_meta($user->ID, 'player_id', true);
    ?>
    <h3>Player Information</h3>
    <table class="form-table">
        <tr>
            <th><label>Player ID</label></th>
            <td>
                <input type="text" value="<?php echo esc_attr($player_id); ?>" class="regular-text" readonly />
                <p class="description">From SSO server</p>
            </td>
        </tr>
    </table>
    <?php
}

// Display in admin user list
add_filter('manage_users_columns', function($columns) {
    $columns['player_id'] = 'Player ID';
    return $columns;
});

add_filter('manage_users_custom_column', function($value, $column_name, $user_id) {
    if ('player_id' === $column_name) {
        return get_user_meta($user_id, 'player_id', true) ?: '-';
    }
    return $value;
}, 10, 3);