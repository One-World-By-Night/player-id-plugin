<?php
/**
 * support.php
 *
 * @author    Justin Greer <justin@justin-greer.com
 * @copyright Justin Greer Interactive, LLC
 * @date      5/8/17
 * @package   WP-Nightly
 */

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
?>

Support Content
