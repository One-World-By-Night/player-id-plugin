<?php

namespace WPOAuth2\OpenID\ResponseType;

use WPOAuth2\ResponseType\ResponseTypeInterface;

interface TokenIdTokenInterface extends ResponseTypeInterface {

}
