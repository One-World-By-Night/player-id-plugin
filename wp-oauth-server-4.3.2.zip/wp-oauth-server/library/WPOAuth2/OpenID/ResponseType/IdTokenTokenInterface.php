<?php

namespace WPOAuth2\OpenID\ResponseType;

use WPOAuth2\ResponseType\ResponseTypeInterface;

interface IdTokenTokenInterface extends ResponseTypeInterface {

}
